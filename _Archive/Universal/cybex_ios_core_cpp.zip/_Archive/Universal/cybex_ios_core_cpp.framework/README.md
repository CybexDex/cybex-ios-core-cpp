Protocol Definition 
--------------------

The classes declared in these headers provide the complete definition of the 
Graphene protocol and are organized according to feature.   Nothing in this
directory should depend upon anything other than fc or other types defined
in the protocol directory.  

To be more specific, implementation details such as the objects defined in
the object database should not be required here.

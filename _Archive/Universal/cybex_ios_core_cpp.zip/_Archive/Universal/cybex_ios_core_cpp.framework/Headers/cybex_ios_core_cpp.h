//
//  cybex_ios_core_cpp.h
//  cybex-ios-core-cpp
//
//  Created by koofrank on 2018/10/19.
//  Copyright © 2018 com.nbltrustdev. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for cybex_ios_core_cpp.
FOUNDATION_EXPORT double cybex_ios_core_cppVersionNumber;

//! Project version string for cybex_ios_core_cpp.
FOUNDATION_EXPORT const unsigned char cybex_ios_core_cppVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <cybex_ios_core_cpp/PublicHeader.h>

#import <cybex_ios_core_cpp/BitShareCoordinator.h>
